/*
 * File: my_model_types.h
 *
 * Code generated for Simulink model 'my_model'.
 *
 * Model version                  : 1.19
 * Simulink Coder version         : 9.8 (R2022b) 13-May-2022
 * C/C++ source code generated on : Thu Feb 22 15:41:09 2024
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objective: Execution efficiency
 * Validation result: Passed (4), Warning (1), Error (0)
 */

#ifndef RTW_HEADER_my_model_types_h_
#define RTW_HEADER_my_model_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_my_model_T RT_MODEL_my_model_T;

#endif                                 /* RTW_HEADER_my_model_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
